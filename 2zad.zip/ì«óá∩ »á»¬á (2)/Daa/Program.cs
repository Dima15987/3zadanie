﻿int number = 15;

if (number % 2 == 0)

{
    Console.WriteLine("Да");
}

else
{
    Console.WriteLine("нет");
}