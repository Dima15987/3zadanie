﻿int a = 23;
int b = 43;

if (a > b )


{
    Console.WriteLine("a = max b = min");
}

else 
{
    Console.WriteLine("b = max a = min");
}

